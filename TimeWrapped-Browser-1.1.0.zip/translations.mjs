export const messages={
 ", без сна — {1}.": [
  ", excluding sleep — {1}.",
  ", без сну — {1}."
 ],
 "0 мин": [
  "0 min",
  "0 хв"
 ],
 "01 / ТВОЯ НЕДЕЛЯ": [
  "01 / YOUR WEEK",
  "01 / ТВІЙ ТИЖДЕНЬ"
 ],
 "02 / ТВОЙ ФАВОРИТ": [
  "02 / YOUR FAVOURITE",
  "02 / ТВІЙ ФАВОРИТ"
 ],
 "03 / ТВОЙ ТОП-5": [
  "03 / YOUR TOP 5",
  "03 / ТВІЙ ТОП-5"
 ],
 "04 / ТВОЙ БАЛАНС": [
  "04 / YOUR BALANCE",
  "04 / ТВІЙ БАЛАНС"
 ],
 "05 / САМЫЙ АКТИВНЫЙ ДЕНЬ": [
  "05 / YOUR BUSIEST DAY",
  "05 / НАЙАКТИВНІШИЙ ДЕНЬ"
 ],
 "06 / СОВА ИЛИ ЖАВОРОНОК?": [
  "06 / NIGHT OWL OR EARLY BIRD?",
  "06 / СОВА ЧИ ЖАЙВОРОНОК?"
 ],
 "07 / СРАВНЕНИЕ НЕДЕЛЬ": [
  "07 / WEEKLY COMPARISON",
  "07 / ПОРІВНЯННЯ ТИЖНІВ"
 ],
 "08 / ТВОЙ ЦИФРОВОЙ ХАРАКТЕР": [
  "08 / YOUR DIGITAL PERSONALITY",
  "08 / ТВІЙ ЦИФРОВИЙ ХАРАКТЕР"
 ],
 "09 / ТВОЯ НЕДЕЛЯ В ОДНОЙ КАРТОЧКЕ": [
  "09 / YOUR WEEK IN ONE CARD",
  "09 / ТВІЙ ТИЖДЕНЬ В ОДНІЙ КАРТЦІ"
 ],
 "100% локально": [
  "100% local",
  "100% локально"
 ],
 "30 дней": [
  "30 days",
  "30 днів"
 ],
 "7 дней": [
  "7 days",
  "7 днів"
 ],
 "9 основных экранов + включённые жанры и личные итоги · ваши настоящие данные · итоговую карточку можно сохранить как PNG": [
  "9 main slides plus enabled genres and private highlights · your actual data · save the final card as PNG",
  "9 основних екранів і ввімкнені жанри та особисті підсумки · ваші справжні дані · підсумкову картку можна зберегти як PNG"
 ],
 "API-ключ {0}": [
  "API key {0}",
  "API-ключ {0}"
 ],
 "CHROME / EDGE · ЛОКАЛЬНО": [
  "CHROME / EDGE · LOCAL",
  "CHROME / EDGE · ЛОКАЛЬНО"
 ],
 "CPU процесса, среднее с запуска": [
  "Process CPU, average since launch",
  "CPU процесу, середнє від запуску"
 ],
 "Chrome / Edge. Записывает название, исполнителя и время состояния «Играет» на soundcloud.com. Пауза в TimeWrapped останавливает запись.": [
  "Chrome / Edge. Records the title, artist and playing time on soundcloud.com. Pausing TimeWrapped stops recording.",
  "Chrome / Edge. Записує назву, виконавця та час відтворення на soundcloud.com. Пауза в TimeWrapped зупиняє запис."
 ],
 "Dota 2 · форма и матчи": [
  "Dota 2 · form and matches",
  "Dota 2 · форма та матчі"
 ],
 "Dotabuff · профиль": [
  "Dotabuff · profile",
  "Dotabuff · профіль"
 ],
 "FACEIT не вернул player_id для CS2": [
  "FACEIT did not return a CS2 player_id",
  "FACEIT не повернув player_id для CS2"
 ],
 "FACEIT-профиль": [
  "FACEIT profile",
  "Профіль FACEIT"
 ],
 "OpenDota · анализ": [
  "OpenDota · analysis",
  "OpenDota · аналіз"
 ],
 "OpenDota не вернул матчи. Возможны закрытые данные или задержка сервиса.": [
  "OpenDota returned no matches. Your data may be private or the service may be delayed.",
  "OpenDota не повернув матчі. Дані можуть бути закритими або сервіс може затримувати оновлення."
 ],
 "STRATZ · статистика": [
  "STRATZ · statistics",
  "STRATZ · статистика"
 ],
 "SoundCloud · вся история": [
  "SoundCloud · all time",
  "SoundCloud · за весь час"
 ],
 "SoundCloud — через дополнение браузера": [
  "SoundCloud — browser companion",
  "SoundCloud — через доповнення браузера"
 ],
 "SoundCloud: пауза": [
  "SoundCloud: paused",
  "SoundCloud: пауза"
 ],
 "SoundCloud: передаём воспроизведение": [
  "SoundCloud: reporting playback",
  "SoundCloud: передаємо відтворення"
 ],
 "Spotify · вся история": [
  "Spotify · all time",
  "Spotify · за весь час"
 ],
 "Spotify на компьютере": [
  "Spotify on your computer",
  "Spotify на комп’ютері"
 ],
 "Spotify — названия треков и исполнители": [
  "Spotify — track titles and artists",
  "Spotify — назви треків і виконавці"
 ],
 "Steam не вернул SteamID64. Вставьте числовую ссылку /profiles/…": [
  "Steam did not return a SteamID64. Paste a numeric /profiles/… link.",
  "Steam не повернув SteamID64. Вставте числове посилання /profiles/…"
 ],
 "Steam-профиль": [
  "Steam profile",
  "Профіль Steam"
 ],
 "Steam-ссылка или SteamID64": [
  "Steam link or SteamID64",
  "Посилання Steam або SteamID64"
 ],
 "TimeWrapped · локальная статистика": [
  "TimeWrapped · local statistics",
  "TimeWrapped · локальна статистика"
 ],
 "TimeWrapped · отслеживание включено": [
  "TimeWrapped · tracking enabled",
  "TimeWrapped · відстеження ввімкнено"
 ],
 "TimeWrapped · пауза": [
  "TimeWrapped · paused",
  "TimeWrapped · пауза"
 ],
 "TimeWrapped не ответил. Проверьте, что приложение запущено.": [
  "TimeWrapped did not respond. Make sure the app is running.",
  "TimeWrapped не відповів. Перевірте, чи запущено застосунок."
 ],
 "TimeWrapped не сохраняет текст окон, нажатия клавиш, скриншоты, переписки и пароли. Основной учёт сохраняет название приложения, категорию и время. История сайтов собирается единым браузерным дополнением только после включения; по умолчанию сохраняются домены и время. История треков в расширениях дополнительно сохраняет название и исполнителя после включения. Игровые расширения запрашивают выбранный публичный профиль у OpenDota и FACEIT; их можно отключить во вкладке «Расширения».": [
  "TimeWrapped does not store window text, keystrokes, screenshots, messages or passwords. Core tracking stores the app name, category and time. Website history is collected by the browser companion only after you enable it; domains and time are saved by default. Optional music history also stores track titles and artists. Gaming extensions request your selected public profile from OpenDota and FACEIT; you can disable them under Extensions.",
  "TimeWrapped не зберігає текст вікон, натискання клавіш, знімки екрана, листування й паролі. Основний облік зберігає назву застосунку, категорію та час. Історія сайтів збирається єдиним доповненням браузера лише після ввімкнення; типово зберігаються домени та час. Необов’язкова історія музики також зберігає назви треків і виконавців. Ігрові розширення запитують вибраний публічний профіль в OpenDota та FACEIT; їх можна вимкнути у вкладці «Розширення»."
 ],
 "TimeWrapped, главная": [
  "TimeWrapped, home",
  "TimeWrapped, головна"
 ],
 "TimeWrapped: запись музыки приостановлена": [
  "TimeWrapped: music recording paused",
  "TimeWrapped: запис музики призупинено"
 ],
 "TimeWrapped: ошибка сохранения": [
  "TimeWrapped: save error",
  "TimeWrapped: помилка збереження"
 ],
 "{0} · {1}% времени": [
  "{0} · {1}% of time",
  "{0} · {1}% часу"
 ],
 "{0} мин": [
  "{0} min",
  "{0} хв"
 ],
 "{0} мониторов · {1} приложений сейчас": [
  "{0} monitors · {1} apps visible now",
  "{0} моніторів · {1} застосунків зараз"
 ],
 "{0} музыки · определено {1}% жанров по исполнителям.": [
  "{0} of music · {1}% of artist genres identified.",
  "{0} музики · визначено {1}% жанрів виконавців."
 ],
 "{0} сек": [
  "{0} sec",
  "{0} с"
 ],
 "{0} ч {1} мин": [
  "{0} h {1} min",
  "{0} год {1} хв"
 ],
 "{0} — твой самый насыщенный цифровой день этой недели.": [
  "{0} was your busiest digital day this week.",
  "{0} — твій найнасиченіший цифровий день цього тижня."
 ],
 "{0}: {1} — {2}% твоей недели": [
  "{0}: {1} — {2}% of your week",
  "{0}: {1} — {2}% твого тижня"
 ],
 "{0}{1}% к предыдущему периоду": [
  "{0}{1}% vs previous period",
  "{0}{1}% до попереднього періоду"
 ],
 "{0}{1}% к прошлой неделе": [
  "{0}{1}% vs last week",
  "{0}{1}% до минулого тижня"
 ],
 "{0}Ваша история хранится на этом компьютере": [
  "{0}Your history is stored on this computer",
  "{0}Ваша історія зберігається на цьому комп’ютері"
 ],
 "{0}Первый отчёт появится после завершения недели с активностью": [
  "{0}Your first report will appear after a completed week with activity",
  "{0}Перший звіт з’явиться після завершення тижня з активністю"
 ],
 "{10} переключений": [
  "{10} switches",
  "{10} перемикань"
 ],
 "{10}Экспорт JSON": [
  "{10}Export JSON",
  "{10}Експорт JSON"
 ],
 "{12}Экспорт CSV": [
  "{12}Export CSV",
  "{12}Експорт CSV"
 ],
 "{15}Измерить": [
  "{15}Measure",
  "{15}Виміряти"
 ],
 "{18}Удалить данные": [
  "{18}Delete data",
  "{18}Видалити дані"
 ],
 "{1} сеансов": [
  "{1} sessions",
  "{1} сеансів"
 ],
 "{1}% игры · {2}% работа · {3}% общение": [
  "{1}% gaming · {2}% work · {3}% social",
  "{1}% ігри · {2}% робота · {3}% спілкування"
 ],
 "{1}. Последнее сообщение браузера: {2}.": [
  "{1}. Last browser message: {2}.",
  "{1}. Останнє повідомлення браузера: {2}."
 ],
 "{2}% суммарного времени приложений": [
  "{2}% of combined app time",
  "{2}% сумарного часу застосунків"
 ],
 "{2}Период": [
  "{2}Date range",
  "{2}Період"
 ],
 "{4} Дополнительно запуск может быть отключён в настройках Windows.": [
  "{4} Startup may also be disabled in Windows settings.",
  "{4} Запуск також може бути вимкнено в налаштуваннях Windows."
 ],
 "{4} сеансов": [
  "{4} sessions",
  "{4} сеансів"
 ],
 "{5} / {6} · ← → для переключения": [
  "{5} / {6} · ← → to navigate",
  "{5} / {6} · ← → для перемикання"
 ],
 "{5}Сохранить карточку PNG": [
  "{5}Save PNG card",
  "{5}Зберегти картку PNG"
 ],
 "{6} программ сейчас запущено": [
  "{6} apps running now",
  "{6} програм зараз запущено"
 ],
 "{6}% времени": [
  "{6}% of time",
  "{6}% часу"
 ],
 "{7} · {8} приложений": [
  "{7} · {8} apps",
  "{7} · {8} застосунків"
 ],
 "{8}Назад": [
  "{8}Back",
  "{8}Назад"
 ],
 "«На экране» — видна хотя бы часть окна, включая обычные окна любого размера. «Только в фоне» — программа работает, но её окно свёрнуто, перекрыто или отсутствует. Сон не увеличивает время программ.": [
  "“On screen” means part of a window is visible, including windows of any size. “Background only” means the app is running but its window is minimized, covered or absent. Sleep does not add app time.",
  "«На екрані» означає, що видно хоча б частину вікна будь-якого розміру. «Лише у фоні» — програма працює, але її вікно згорнуте, перекрите або відсутнє. Сон не збільшує час програм."
 ],
 "· {2} игр": [
  "· {2} games",
  "· {2} ігор"
 ],
 "· сохранён": [
  "· saved",
  "· збережено"
 ],
 "Автозапуск TimeWrapped": [
  "TimeWrapped startup",
  "Автозапуск TimeWrapped"
 ],
 "Автозапуск Windows": [
  "Windows startup",
  "Автозапуск Windows"
 ],
 "Активность распределена по дню: менее 35% ночью и менее 40% утром.": [
  "Activity is spread throughout the day: under 35% at night and under 40% in the morning.",
  "Активність розподілена протягом дня: менш як 35% уночі та менш як 40% уранці."
 ],
 "Активный фокус": [
  "Active focus",
  "Активний фокус"
 ],
 "БЕЗ API-КЛЮЧА": [
  "NO API KEY",
  "БЕЗ API-КЛЮЧА"
 ],
 "БЕЗ ВХОДА В STEAM": [
  "NO STEAM SIGN-IN",
  "БЕЗ ВХОДУ В STEAM"
 ],
 "База создана более новой версией TimeWrapped. Обновите приложение.": [
  "This database was created by a newer version of TimeWrapped. Update the app.",
  "Цю базу створено новішою версією TimeWrapped. Оновіть застосунок."
 ],
 "Без аккаунтов и облака.": [
  "No accounts or cloud.",
  "Без облікових записів і хмари."
 ],
 "Без изменений": [
  "No change",
  "Без змін"
 ],
 "Без ключа · публичная статистика": [
  "No key · public statistics",
  "Без ключа · публічна статистика"
 ],
 "Без ранга": [
  "Unranked",
  "Без рангу"
 ],
 "Без распознанного фокуса": [
  "Unattributed focus",
  "Без розпізнаного фокуса"
 ],
 "Без сна: {6}. Этот счётчик включает время до запуска TimeWrapped.": [
  "Excluding sleep: {6}. Includes time before TimeWrapped was started.",
  "Без сну: {6}. Враховує час до запуску TimeWrapped."
 ],
 "Блокировка": [
  "Locked",
  "Блокування"
 ],
 "Браузер": [
  "Browser",
  "Браузер"
 ],
 "Браузер не ответил на проверку разрешений": [
  "The browser did not respond to the permission check",
  "Браузер не відповів на перевірку дозволів"
 ],
 "Браузер не ответил при чтении настроек": [
  "The browser did not respond while reading settings",
  "Браузер не відповів під час читання налаштувань"
 ],
 "Будут удалены сессии и статистика приложений, включая прошлые Wrapped. Настройки сохранятся. Это действие нельзя отменить.": [
  "This deletes sessions and app statistics, including past Wrapped reports. Settings are kept. This cannot be undone.",
  "Буде видалено сеанси та статистику застосунків, зокрема минулі Wrapped. Налаштування збережуться. Цю дію не можна скасувати."
 ],
 "Будут удалены только сеансы сайтов 18+. При включённом сборе новые посещения продолжат записываться.": [
  "Only adult-site sessions will be deleted. If tracking is enabled, new visits will still be recorded.",
  "Буде видалено лише сеанси сайтів 18+. Якщо збір увімкнено, нові відвідування продовжать записуватися."
 ],
 "Были на экране": [
  "Were on screen",
  "Були на екрані"
 ],
 "В": [
  "W",
  "П"
 ],
 "В Windows указан другой путь. Нажмите «Применить заново».": [
  "Windows points to a different path. Click “Apply again”.",
  "У Windows вказано інший шлях. Натисніть «Застосувати знову»."
 ],
 "В браузере включена пауза. Нажмите «Возобновить сбор».": [
  "Browser tracking is paused. Click “Resume tracking”.",
  "У браузері ввімкнено паузу. Натисніть «Відновити збір»."
 ],
 "В своём темпе": [
  "At your own pace",
  "У власному темпі"
 ],
 "В фоне работает лёгкий нативный сборщик. Окно можно спокойно закрыть.": [
  "A lightweight native collector runs in the background. You can close this window.",
  "У фоні працює легкий нативний збирач. Вікно можна спокійно закрити."
 ],
 "В этом периоде ещё нет посещений": [
  "No visits in this period yet",
  "У цьому періоді ще немає відвідувань"
 ],
 "ВАШ ЦИФРОВОЙ РИТМ": [
  "YOUR DIGITAL RHYTHM",
  "ВАШ ЦИФРОВИЙ РИТМ"
 ],
 "ВАША ИСТОРИЯ ГОТОВА": [
  "YOUR STORY IS READY",
  "ВАША ІСТОРІЯ ГОТОВА"
 ],
 "ВАШЕ ВРЕМЯ. ВАША ИСТОРИЯ.": [
  "YOUR TIME. YOUR STORY.",
  "ВАШ ЧАС. ВАША ІСТОРІЯ."
 ],
 "ВРЕМЕНИ ПК": [
  "OF PC TIME",
  "ЧАСУ ПК"
 ],
 "ВРЕМЯ ВСПОМНИТЬ": [
  "TIME TO REMEMBER",
  "ЧАС ЗГАДАТИ"
 ],
 "Ваш баланс": [
  "Your balance",
  "Ваш баланс"
 ],
 "Ваш день, в деталях.": [
  "Your day, in detail.",
  "Ваш день, у деталях."
 ],
 "Ваша неделя.": [
  "Your week.",
  "Ваш тиждень."
 ],
 "Ваше время сейчас не записывается": [
  "Your time is not being recorded",
  "Ваш час зараз не записується"
 ],
 "Ваше время. Ваши правила.": [
  "Your time. Your rules.",
  "Ваш час. Ваші правила."
 ],
 "Ваши сайты": [
  "Your websites",
  "Ваші сайти"
 ],
 "Введите": [
  "Type",
  "Введіть"
 ],
 "Вернитесь к любому периоду и посмотрите, как менялся ваш ритм.": [
  "Return to any period and see how your rhythm changed.",
  "Поверніться до будь-якого періоду й подивіться, як змінювався ваш ритм."
 ],
 "Видимые приложения (сумма)": [
  "Visible apps (combined)",
  "Видимі застосунки (сума)"
 ],
 "Видно окно: {2} · Только в фоне: {3} · Запущено: {4}": [
  "Window visible: {2} · Background only: {3} · Running: {4}",
  "Вікно видно: {2} · Лише у фоні: {3} · Запущено: {4}"
 ],
 "Вкладка браузера не ответила. Обновите её страницу.": [
  "A browser tab did not respond. Reload its page.",
  "Вкладка браузера не відповіла. Оновіть її сторінку."
 ],
 "Включено. Новая история начнётся сейчас.": [
  "Enabled. New history starts now.",
  "Увімкнено. Нова історія починається зараз."
 ],
 "Включите историю сайтов здесь, чтобы разрешить доступ браузера.": [
  "Enable website history here to grant browser access.",
  "Увімкніть історію сайтів тут, щоб надати доступ браузера."
 ],
 "Включите нужные функции в его панели. Для сайтов браузер отдельно запросит доступ. Уже открытый SoundCloud после установки обновите.": [
  "Enable the features you need in its panel. Website access requires separate browser permission. Reload SoundCloud if it was already open during installation.",
  "Увімкніть потрібні функції в його панелі. Для сайтів браузер окремо запросить дозвіл. Оновіть SoundCloud, якщо його було відкрито під час встановлення."
 ],
 "Включите нужный сервис и запустите воспроизведение.": [
  "Enable a service and start playback.",
  "Увімкніть потрібний сервіс і запустіть відтворення."
 ],
 "Возможности дополнения": [
  "Companion features",
  "Можливості доповнення"
 ],
 "Возобновить сбор в браузере": [
  "Resume browser tracking",
  "Відновити збір у браузері"
 ],
 "Вот как звучала": [
  "Listen to",
  "Ось як звучав"
 ],
 "Вот как прошла": [
  "Remember",
  "Ось як минув"
 ],
 "Время": [
  "Time",
  "Час"
 ],
 "Время 18+": [
  "Adult-site time",
  "Час на сайтах 18+"
 ],
 "Время ПК": [
  "PC time",
  "Час ПК"
 ],
 "Время ПК по часам": [
  "PC time by hour",
  "Час ПК за годинами"
 ],
 "Время ПК по часам. {0}": [
  "PC time by hour. {0}",
  "Час ПК за годинами. {0}"
 ],
 "Время без активности": [
  "Idle time",
  "Час без активності"
 ],
 "Время и сеансы просмотра на сайтах 18+.": [
  "Time and visits on adult sites.",
  "Час і відвідування сайтів 18+."
 ],
 "Время на сайтах": [
  "Time on websites",
  "Час на сайтах"
 ],
 "Время просмотра на сайтах 18+ за выбранную неделю.": [
  "Time spent on adult sites in the selected week.",
  "Час перегляду сайтів 18+ за вибраний тиждень."
 ],
 "Время складывается в историю.": [
  "Time becomes a story.",
  "Час складається в історію."
 ],
 "Все": [
  "All",
  "Усі"
 ],
 "Все доступные показатели": [
  "All available statistics",
  "Усі доступні показники"
 ],
 "Все сайты": [
  "All websites",
  "Усі сайти"
 ],
 "Вставьте код подключения": [
  "Paste the pairing code",
  "Вставте код підключення"
 ],
 "Вставьте код подключения в настройках дополнения": [
  "Paste the pairing code in the companion settings",
  "Вставте код підключення в налаштуваннях доповнення"
 ],
 "Вставьте код подключения из TimeWrapped": [
  "Paste the pairing code from TimeWrapped",
  "Вставте код підключення з TimeWrapped"
 ],
 "Вставьте полную HTTPS-ссылку Steam-профиля или SteamID64": [
  "Paste the full HTTPS Steam profile link or SteamID64",
  "Вставте повне HTTPS-посилання профілю Steam або SteamID64"
 ],
 "Вставьте ссылку на профиль, без разделов games или inventory": [
  "Paste a profile link without games or inventory sections",
  "Вставте посилання на профіль без розділів games або inventory"
 ],
 "Всё время": [
  "All time",
  "За весь час"
 ],
 "Всё начинается": [
  "It all starts",
  "Усе починається"
 ],
 "Всё учтённое время включённого ПК": [
  "All tracked PC uptime",
  "Увесь облікований час увімкненого ПК"
 ],
 "Входит во время ПК; видимые окна продолжают учитываться": [
  "Included in PC time; visible windows continue to count",
  "Входить у час ПК; видимі вікна продовжують враховуватися"
 ],
 "Вчера": [
  "Yesterday",
  "Учора"
 ],
 "Вы часто были вместе.": [
  "You were often together.",
  "Ви часто були разом."
 ],
 "Выберите историю": [
  "Choose a story",
  "Виберіть історію"
 ],
 "Выберите период до 366 дней": [
  "Choose a period of up to 366 days",
  "Виберіть період до 366 днів"
 ],
 "Выберите период от 1 дня до 10 лет.": [
  "Choose a period from 1 day to 10 years.",
  "Виберіть період від 1 дня до 10 років."
 ],
 "Выберите публичный режим или API FACEIT": [
  "Choose public mode or FACEIT API",
  "Виберіть публічний режим або API FACEIT"
 ],
 "Выбранный период": [
  "Selected period",
  "Вибраний період"
 ],
 "Выключено. Накопленная история сохранена.": [
  "Disabled. Your existing history is kept.",
  "Вимкнено. Накопичену історію збережено."
 ],
 "Герои, на которых получается": [
  "Heroes you do well with",
  "Герої, на яких вдається"
 ],
 "Герой #{0}": [
  "Hero #{0}",
  "Герой №{0}"
 ],
 "Герой / матч": [
  "Hero / match",
  "Герой / матч"
 ],
 "Главные герои недели.": [
  "The main characters of your week.",
  "Головні герої тижня."
 ],
 "Главный фаворит": [
  "Top favourite",
  "Головний фаворит"
 ],
 "Готов к подключению браузерного дополнения": [
  "Ready to connect the browser companion",
  "Готово до підключення браузерного доповнення"
 ],
 "Готово": [
  "Done",
  "Готово"
 ],
 "График заполнится по мере активности. Простой, блокировка и сон входят во время ПК.": [
  "The chart fills as you use your PC. Idle, lock and sleep are included in PC time.",
  "Графік заповнюється з активністю. Простій, блокування та сон входять у час ПК."
 ],
 "ДОПОЛНИТЕ СВОЮ ИСТОРИЮ": [
  "ADD TO YOUR STORY",
  "ДОПОВНІТЬ СВОЮ ІСТОРІЮ"
 ],
 "ДРОЧУН · 18+": [
  "ADULT SITES · 18+",
  "САЙТИ 18+"
 ],
 "Дальше": [
  "Next",
  "Далі"
 ],
 "Данные на устройстве": [
  "On-device data",
  "Дані на пристрої"
 ],
 "Данные под вашим контролем": [
  "Your data, your control",
  "Дані під вашим контролем"
 ],
 "Данные хранятся на этом компьютере. В обычную PNG-карточку Wrapped статистика 18+ не добавляется.": [
  "Data is stored on this computer. Adult-site statistics are excluded from the standard Wrapped PNG card.",
  "Дані зберігаються на цьому комп’ютері. Статистика 18+ не додається до звичайної PNG-картки Wrapped."
 ],
 "Дата в нужном периоде": [
  "Date within the period",
  "Дата в потрібному періоді"
 ],
 "Дата вне диапазона": [
  "Date out of range",
  "Дата поза діапазоном"
 ],
 "Дата вне допустимого диапазона.": [
  "Date outside the allowed range.",
  "Дата поза допустимим діапазоном."
 ],
 "Дата должна быть в формате ГГГГ-ММ-ДД.": [
  "Use the YYYY-MM-DD date format.",
  "Дата має бути у форматі РРРР-ММ-ДД."
 ],
 "Дата начала должна быть не позже даты окончания": [
  "The start date must not be after the end date",
  "Дата початку не може бути пізнішою за дату завершення"
 ],
 "Длительность": [
  "Duration",
  "Тривалість"
 ],
 "Для всего": [
  "For everything",
  "Для всього"
 ],
 "Для обновления замените файлы в той же папке и нажмите ↻ у существующего TimeWrapped в браузере. Если ранее загрузили несколько копий, удалите старые карточки, оставив одну. Новые версии используют постоянный идентификатор.": [
  "To update, replace files in the same folder and click ↻ on the existing TimeWrapped extension. If you loaded multiple copies, remove the old ones and keep one. New versions use a permanent ID.",
  "Для оновлення замініть файли в тій самій папці та натисніть ↻ біля наявного TimeWrapped у браузері. Якщо завантажили кілька копій, видаліть старі, залишивши одну. Нові версії мають постійний ідентифікатор."
 ],
 "Для режима FACEIT API нужен ключ. Выберите публичный режим для просмотра без ключа": [
  "FACEIT API mode requires a key. Select public mode to view statistics without a key.",
  "Для режиму FACEIT API потрібен ключ. Виберіть публічний режим для перегляду без ключа."
 ],
 "Для цифрового типа нужна завершённая неделя с активностью.": [
  "A completed week with activity is needed to determine your digital type.",
  "Для цифрового типу потрібен завершений тиждень з активністю."
 ],
 "Для этой недели пока недостаточно данных": [
  "Not enough data for this week yet",
  "Для цього тижня ще недостатньо даних"
 ],
 "До 300 последних сеансов выбранного сайта за период. Возврат к вкладке начинает новый сеанс.": [
  "Up to 300 recent sessions for the selected site and period. Returning to a tab starts a new session.",
  "До 300 останніх сеансів вибраного сайту за період. Повернення до вкладки починає новий сеанс."
 ],
 "Документация FACEIT": [
  "FACEIT documentation",
  "Документація FACEIT"
 ],
 "Домены, время и сеансы просмотра. Нужно включить сбор также в браузерном дополнении.": [
  "Domains, time and visits. Website access must be granted in the browser companion.",
  "Домени, час і відвідування. Доступ до сайтів потрібно надати в браузерному доповненні."
 ],
 "Дополнение не ответило. Нажмите «Подключить» ещё раз; если ошибка повторится, нажмите ↻ у TimeWrapped на странице расширений.": [
  "The companion did not respond. Click “Connect” again; if it happens again, click ↻ on TimeWrapped on the extensions page.",
  "Доповнення не відповіло. Натисніть «Підключити» ще раз; якщо помилка повториться, натисніть ↻ біля TimeWrapped на сторінці розширень."
 ],
 "Дополнение сохранено:": [
  "Companion saved:",
  "Доповнення збережено:"
 ],
 "Дополнительно к доменам. Query-параметры и фрагменты URL всегда отбрасываются.": [
  "In addition to domains. URL query parameters and fragments are always removed.",
  "Додатково до доменів. Параметри запиту та фрагменти URL завжди відкидаються."
 ],
 "Дополнительные домены 18+": [
  "Additional adult domains",
  "Додаткові домени 18+"
 ],
 "Допускается только имя исполняемого файла, без пути.": [
  "Only an executable filename is allowed, without a path.",
  "Дозволено лише ім’я виконуваного файла без шляху."
 ],
 "Доступ не выдан. История сайтов остаётся выключенной.": [
  "Access was not granted. Website history stays off.",
  "Доступ не надано. Історія сайтів залишається вимкненою."
 ],
 "Дрочун": [
  "Adult sites",
  "Сайти 18+"
 ],
 "Другое": [
  "Other",
  "Інше"
 ],
 "Ещё впереди": [
  "Still ahead",
  "Ще попереду"
 ],
 "Ещё не обновлялось": [
  "Not updated yet",
  "Ще не оновлювалося"
 ],
 "Жаворонок": [
  "Early bird",
  "Жайворонок"
 ],
 "Жанр задаётся исполнителю и распределяет время его прослушивания. Это может отличаться от жанра конкретного трека.": [
  "A genre is assigned to an artist and groups their listening time. It may differ from an individual track’s genre.",
  "Жанр призначається виконавцю та групує час його прослуховування. Він може відрізнятися від жанру окремого треку."
 ],
 "Жанр не определён": [
  "Unknown genre",
  "Жанр не визначено"
 ],
 "Ждём медиастатус Windows": [
  "Waiting for Windows media status",
  "Очікуємо медіастатус Windows"
 ],
 "Ждём сборщик": [
  "Waiting for collector",
  "Очікуємо збирач"
 ],
 "Живите в своём ритме. TimeWrapped тихо собирает моменты, чтобы после завершения недели превратить их в вашу историю.": [
  "Live at your own pace. TimeWrapped quietly collects moments and turns them into your story once the week is complete.",
  "Живіть у власному ритмі. TimeWrapped тихо збирає моменти, щоб після завершення тижня перетворити їх на вашу історію."
 ],
 "За записанную неделю набралось менее 7 часов активного времени. Тип описывает только собранные данные.": [
  "Less than 7 hours of active time were recorded this week. The type reflects recorded data only.",
  "За записаний тиждень набралося менш як 7 годин активного часу. Тип описує лише зібрані дані."
 ],
 "За одно обновление — до 10 исполнителей. Можно задать жанры вручную.": [
  "Up to 10 artists per refresh. You can set genres manually.",
  "До 10 виконавців за одне оновлення. Жанри можна задати вручну."
 ],
 "За эту неделю нет активных приложений.": [
  "No active apps this week.",
  "За цей тиждень немає активних застосунків."
 ],
 "Загружаем настройки расширений…": [
  "Loading extension settings…",
  "Завантажуємо налаштування розширень…"
 ],
 "Закрепите значок TimeWrapped. Вставьте код ниже и нажмите «Подключить».": [
  "Pin TimeWrapped. Paste the code below and click “Connect”.",
  "Закріпіть значок TimeWrapped. Вставте код нижче й натисніть «Підключити»."
 ],
 "Закрыть историю": [
  "Close story",
  "Закрити історію"
 ],
 "Замечайте привычки. Находите время для важного.": [
  "Notice your habits. Make time for what matters.",
  "Помічайте звички. Знаходьте час для важливого."
 ],
 "Записи TimeWrapped в автозапуске Windows нет.": [
  "TimeWrapped is not registered in Windows startup.",
  "Запису TimeWrapped в автозапуску Windows немає."
 ],
 "Запись автозапуска указывает на текущую версию.": [
  "The startup entry points to the current version.",
  "Запис автозапуску вказує на поточну версію."
 ],
 "Запускать TimeWrapped вместе с Windows": [
  "Start TimeWrapped with Windows",
  "Запускати TimeWrapped разом із Windows"
 ],
 "Запущено всего": [
  "Total running",
  "Запущено загалом"
 ],
 "Здесь появятся ваши приложения": [
  "Your apps will appear here",
  "Тут з’являться ваші застосунки"
 ],
 "Здесь появятся прослушанные треки": [
  "Your listening history will appear here",
  "Тут з’являться прослухані треки"
 ],
 "Знакомые приложения. Неожиданные открытия. Ваши итоги уже ждут.": [
  "Familiar apps. Unexpected discoveries. Your highlights are waiting.",
  "Знайомі застосунки. Несподівані відкриття. Ваші підсумки вже чекають."
 ],
 "ИСТОРИЯ": [
  "HISTORY",
  "ІСТОРІЯ"
 ],
 "ИСТОРИЯ ВАШЕГО ВРЕМЕНИ": [
  "THE STORY OF YOUR TIME",
  "ІСТОРІЯ ВАШОГО ЧАСУ"
 ],
 "Игровой стратег": [
  "Gaming strategist",
  "Ігровий стратег"
 ],
 "Игрок #": [
  "Player #",
  "Гравець №"
 ],
 "Игры": [
  "Games",
  "Ігри"
 ],
 "Имена исполнителей отправляются в MusicBrainz. Неоднозначные совпадения остаются без жанра; ручной выбор имеет приоритет.": [
  "Artist names are sent to MusicBrainz. Ambiguous matches remain unclassified; manual choices take priority.",
  "Імена виконавців надсилаються в MusicBrainz. Неоднозначні збіги залишаються без жанру; ручний вибір має пріоритет."
 ],
 "Инкогнито и старая история не собираются. Параметры URL, пароли и содержимое страниц не передаются. Списки исключений находятся в приложении.": [
  "Incognito and past history are not collected. URL parameters, passwords and page contents are not sent. Exclusion lists are in the app.",
  "Інкогніто та стара історія не збираються. Параметри URL, паролі й вміст сторінок не передаються. Списки винятків — у застосунку."
 ],
 "Искать жанры в MusicBrainz": [
  "Look up genres on MusicBrainz",
  "Шукати жанри в MusicBrainz"
 ],
 "Исключить": [
  "Exclude",
  "Виключити"
 ],
 "Исполнители появятся после включения истории треков и прослушивания музыки.": [
  "Artists appear after you enable track history and listen to music.",
  "Виконавці з’являться після ввімкнення історії треків і прослуховування музики."
 ],
 "Исполнитель не передан": [
  "Artist not provided",
  "Виконавця не передано"
 ],
 "Используется единое дополнение TimeWrapped.": [
  "Uses the single TimeWrapped companion.",
  "Використовується єдине доповнення TimeWrapped."
 ],
 "История": [
  "History",
  "Історія"
 ],
 "История 18+": [
  "Adult-site history",
  "Історія 18+"
 ],
 "История 18+ удалена": [
  "Adult-site history deleted",
  "Історію 18+ видалено"
 ],
 "История FACEIT ещё не загружена": [
  "FACEIT history has not loaded yet",
  "Історію FACEIT ще не завантажено"
 ],
 "История SoundCloud": [
  "SoundCloud history",
  "Історія SoundCloud"
 ],
 "История выбранного сайта": [
  "Selected website history",
  "Історія вибраного сайту"
 ],
 "История музыки": [
  "Music history",
  "Історія музики"
 ],
 "История начинается после включения; инкогнито и старые посещения не импортируются. Учитывается активная вкладка окна с фокусом. Настройки общие с приложением. Данные отправляются только на этот ПК.": [
  "History starts after you enable tracking; incognito and old visits are not imported. Only the active tab in the focused window adds website time. Settings are shared with the app. Data is sent only to this PC.",
  "Історія починається після ввімкнення; інкогніто та старі відвідування не імпортуються. Час сайту додає лише активна вкладка вікна з фокусом. Налаштування спільні із застосунком. Дані надсилаються лише на цей ПК."
 ],
 "История сайтов": [
  "Website history",
  "Історія сайтів"
 ],
 "История сайтов начнёт заполняться после подключения дополнения.": [
  "Website history starts filling after you connect the companion.",
  "Історія сайтів почне заповнюватися після підключення доповнення."
 ],
 "История содержит только наблюдавшиеся интервалы. {3} Ранее пропущенную историю приложений восстановить нельзя. Автозапуск помогает собирать весь день.": [
  "History contains only observed intervals. {3} Missing past app activity cannot be reconstructed. Startup helps capture the whole day.",
  "Історія містить лише спостережені інтервали. {3} Пропущену історію застосунків відновити неможливо. Автозапуск допомагає збирати весь день."
 ],
 "История треков Spotify": [
  "Spotify track history",
  "Історія треків Spotify"
 ],
 "История треков настольного плеера": [
  "Desktop player track history",
  "Історія треків настільного плеєра"
 ],
 "История удалена. Можно начать новую главу.": [
  "History deleted. You can start a new chapter.",
  "Історію видалено. Можна почати новий розділ."
 ],
 "Итоги по жанрам": [
  "Genre highlights",
  "Підсумки за жанрами"
 ],
 "Итоги по жанрам музыки": [
  "Music genre highlights",
  "Підсумки за жанрами музики"
 ],
 "Итоги расширений · неделя и месяц": [
  "Extension highlights · week and month",
  "Підсумки розширень · тиждень і місяць"
 ],
 "Каждое видимое приложение получает время параллельно, даже без ввода. Полностью перекрытые и свёрнутые окна не получают время «На экране». Одно приложение на нескольких мониторах считается один раз. Сумма приложений может быть больше времени ПК; доли категорий рассчитаны от этой суммы.": [
  "Every visible app receives time in parallel, even without input. Fully covered and minimized windows do not receive on-screen time. An app shown on multiple monitors is counted once. Combined app time can exceed PC time; category shares use that combined total.",
  "Кожен видимий застосунок отримує час паралельно, навіть без введення. Повністю перекриті та згорнуті вікна не отримують час «На екрані». Один застосунок на кількох моніторах рахується один раз. Сума часу застосунків може перевищувати час ПК; частки категорій розраховані від цієї суми."
 ],
 "Каждый день — начало.": [
  "Every day is a new beginning.",
  "Кожен день — початок."
 ],
 "Как запускать": [
  "Launch mode",
  "Режим запуску"
 ],
 "Как появятся итоги": [
  "How highlights become available",
  "Як з’являться підсумки"
 ],
 "Как прошёл вчерашний день.": [
  "How yesterday went.",
  "Як минув учорашній день."
 ],
 "Карточка сохранена:": [
  "Card saved:",
  "Картку збережено:"
 ],
 "Категория {5}": [
  "Category: {5}",
  "Категорія: {5}"
 ],
 "Ключ FACEIT Data API": [
  "FACEIT Data API key",
  "Ключ FACEIT Data API"
 ],
 "Ключ защищён и сохранён": [
  "Key protected and saved",
  "Ключ захищено та збережено"
 ],
 "Когда": [
  "When",
  "Коли"
 ],
 "Кого чаще встречаете в одной команде, от 5 матчей.": [
  "Frequent teammates, with at least 5 matches.",
  "Часті напарники, від 5 матчів."
 ],
 "Код из приложения → Расширения → Браузер": [
  "Code from the app → Extensions → Browser",
  "Код із застосунку → Розширення → Браузер"
 ],
 "Код подключения браузера": [
  "Browser pairing code",
  "Код підключення браузера"
 ],
 "Код скопирован": [
  "Code copied",
  "Код скопійовано"
 ],
 "Копировать код": [
  "Copy code",
  "Копіювати код"
 ],
 "ЛИЧНАЯ СТАТИСТИКА · 18+": [
  "PRIVATE STATISTICS · 18+",
  "ОСОБИСТА СТАТИСТИКА · 18+"
 ],
 "ЛИЧНОЕ ПРОСТРАНСТВО": [
  "PERSONAL SPACE",
  "ОСОБИСТИЙ ПРОСТІР"
 ],
 "ЛИЧНЫЙ РАЗДЕЛ · 18+": [
  "PRIVATE SECTION · 18+",
  "ОСОБИСТИЙ РОЗДІЛ · 18+"
 ],
 "ЛОКАЛЬНО · ПОСЛЕ ВКЛЮЧЕНИЯ": [
  "LOCAL · AFTER YOU ENABLE IT",
  "ЛОКАЛЬНО · ПІСЛЯ ВВІМКНЕННЯ"
 ],
 "ЛЮБИМОЕ ПРИЛОЖЕНИЕ": [
  "FAVOURITE APP",
  "УЛЮБЛЕНИЙ ЗАСТОСУНОК"
 ],
 "Личный раздел · 18+": [
  "Private section · 18+",
  "Особистий розділ · 18+"
 ],
 "Личный раздел и итоги в приложении": [
  "Private section and highlights in the app",
  "Особистий розділ і підсумки в застосунку"
 ],
 "Локальный профиль": [
  "Local profile",
  "Локальний профіль"
 ],
 "Любая неделя": [
  "Any week",
  "Будь-який тиждень"
 ],
 "Любимое приложение": [
  "Favourite app",
  "Улюблений застосунок"
 ],
 "Любой месяц": [
  "Any month",
  "Будь-який місяць"
 ],
 "МБ": [
  "MB",
  "МБ"
 ],
 "МОЁ ПРОСТРАНСТВО": [
  "MY SPACE",
  "МІЙ ПРОСТІР"
 ],
 "МУЗЫКА НЕДЕЛИ": [
  "MUSIC OF THE WEEK",
  "МУЗИКА ТИЖНЯ"
 ],
 "Максимум 200 доменов в списке": [
  "Maximum 200 domains per list",
  "Не більш як 200 доменів у списку"
 ],
 "Мастер многозадачности": [
  "Multitasking master",
  "Майстер багатозадачності"
 ],
 "Матч / карта": [
  "Match / map",
  "Матч / карта"
 ],
 "Матч CS2": [
  "CS2 match",
  "Матч CS2"
 ],
 "Матчей · OpenDota": [
  "Matches · OpenDota",
  "Матчі · OpenDota"
 ],
 "Матчей · всего": [
  "Matches · all time",
  "Матчі · загалом"
 ],
 "Между активными приложениями": [
  "Between active apps",
  "Між активними застосунками"
 ],
 "Месяц": [
  "Month",
  "Місяць"
 ],
 "Моё пространство": [
  "My space",
  "Мій простір"
 ],
 "Музыка": [
  "Music",
  "Музика"
 ],
 "Музыка в Spotify": [
  "Music on Spotify",
  "Музика в Spotify"
 ],
 "Музыка, матчи и немного больше о ваших привычках.": [
  "Music, matches and more about your habits.",
  "Музика, матчі й трохи більше про ваші звички."
 ],
 "Музыкальные жанры": [
  "Music genres",
  "Музичні жанри"
 ],
 "НАСТРОЙКИ": [
  "SETTINGS",
  "НАЛАШТУВАННЯ"
 ],
 "НАСТРОЙКИ И КОНФИДЕНЦИАЛЬНОСТЬ": [
  "SETTINGS & PRIVACY",
  "НАЛАШТУВАННЯ ТА КОНФІДЕНЦІЙНІСТЬ"
 ],
 "На экране": [
  "On screen",
  "На екрані"
 ],
 "На экране и в фоне — отдельно": [
  "On screen and in the background — separately",
  "На екрані та у фоні — окремо"
 ],
 "Нажми на категорию, чтобы узнать её долю в твоей неделе.": [
  "Click a category to see its share of your week.",
  "Натисни на категорію, щоб побачити її частку у твоєму тижні."
 ],
 "Нажмите «Измерить», чтобы получить показатели фонового процесса. Цели: CPU менее 0,5% в среднем, RAM 20–35 МБ. Достижение целей проверяется измерением.": [
  "Click “Measure” to view the background process metrics. Targets: average CPU below 0.5%, RAM 20–35 MB. These targets require measurement.",
  "Натисніть «Виміряти», щоб побачити показники фонового процесу. Цілі: CPU нижче 0,5% у середньому, RAM 20–35 МБ. Досягнення цілей перевіряється вимірюванням."
 ],
 "Нажмите «Обновить расширения». Для истории матчей нужны публичные данные Dota.": [
  "Click “Refresh extensions”. Dota match history requires public data.",
  "Натисніть «Оновити розширення». Для історії матчів потрібні публічні дані Dota."
 ],
 "Названия и пути страниц": [
  "Page titles and paths",
  "Назви та шляхи сторінок"
 ],
 "Найти приложение": [
  "Find an app",
  "Знайти застосунок"
 ],
 "Найти приложение в статистике": [
  "Find an app in statistics",
  "Знайти застосунок у статистиці"
 ],
 "Настольный Spotify. История записывается при подтверждённом воспроизведении, также в фоне. Вход в Spotify через TimeWrapped не нужен.": [
  "Desktop Spotify. History records confirmed playback, including background playback. You do not need to sign into Spotify through TimeWrapped.",
  "Настільний Spotify. Історія записується за підтвердженого відтворення, зокрема у фоні. Вхід у Spotify через TimeWrapped не потрібен."
 ],
 "Настроить расширение": [
  "Set up extension",
  "Налаштувати розширення"
 ],
 "Настройка расширения сохранена": [
  "Extension setting saved",
  "Налаштування розширення збережено"
 ],
 "Настройка сохранена": [
  "Setting saved",
  "Налаштування збережено"
 ],
 "Настройки": [
  "Settings",
  "Налаштування"
 ],
 "Настройки автозапуска Windows": [
  "Windows startup settings",
  "Налаштування автозапуску Windows"
 ],
 "Настройки общие с приложением. Изменения сохраняются сразу.": [
  "Settings are shared with the app. Changes are saved immediately.",
  "Налаштування спільні із застосунком. Зміни зберігаються одразу."
 ],
 "Настройте сбор статистики так, как удобно вам.": [
  "Set up tracking the way you prefer.",
  "Налаштуйте збір статистики так, як вам зручно."
 ],
 "Начать с чистого листа": [
  "Start fresh",
  "Почати з чистого аркуша"
 ],
 "Начинайте собирать статистику после входа в свой профиль Windows.": [
  "Start collecting statistics when you sign into Windows.",
  "Починайте збирати статистику після входу у свій профіль Windows."
 ],
 "Не определена полночь": [
  "Could not determine midnight",
  "Не вдалося визначити опівніч"
 ],
 "Не определён": [
  "Unknown",
  "Не визначено"
 ],
 "Не просто цифры — ваша персональная цифровая история.": [
  "More than numbers — your personal digital story.",
  "Не просто цифри — ваша особиста цифрова історія."
 ],
 "Не создан код подключения": [
  "Pairing code was not created",
  "Код підключення не створено"
 ],
 "Не удалось выполнить действие": [
  "Could not complete the action",
  "Не вдалося виконати дію"
 ],
 "Не удалось записать музыку\\": [
  "Could not record music\\",
  "Не вдалося записати музику\\"
 ],
 "Не удалось определить локальную дату": [
  "Could not determine the local date",
  "Не вдалося визначити локальну дату"
 ],
 "Не удалось получить ответ TimeWrapped": [
  "Could not receive a response from TimeWrapped",
  "Не вдалося отримати відповідь TimeWrapped"
 ],
 "Не удалось получить статистику.": [
  "Could not load statistics.",
  "Не вдалося отримати статистику."
 ],
 "Не удалось применить настройки сборщика": [
  "Could not apply collector settings",
  "Не вдалося застосувати налаштування збирача"
 ],
 "Не удалось прочитать код подключения": [
  "Could not read the pairing code",
  "Не вдалося прочитати код підключення"
 ],
 "Не удалось создать код подключения": [
  "Could not create a pairing code",
  "Не вдалося створити код підключення"
 ],
 "Не удалось сохранить код подключения": [
  "Could not save the pairing code",
  "Не вдалося зберегти код підключення"
 ],
 "Не удалось сохранить текущую статистику. Подробности в agent-error.log.": [
  "Could not save current statistics. See agent-error.log for details.",
  "Не вдалося зберегти поточну статистику. Подробиці в agent-error.log."
 ],
 "Не учитывать эти домены": [
  "Exclude these domains",
  "Не враховувати ці домени"
 ],
 "Неверный код подключения. Скопируйте его заново из приложения.": [
  "Incorrect pairing code. Copy it again from the app.",
  "Неправильний код підключення. Скопіюйте його ще раз із застосунку."
 ],
 "Неверный код подключения\\": [
  "Incorrect pairing code\\",
  "Неправильний код підключення\\"
 ],
 "Неделя": [
  "Week",
  "Тиждень"
 ],
 "Неделя в одном взгляде": [
  "Your week at a glance",
  "Тиждень одним поглядом"
 ],
 "Неделя должна начинаться в понедельник.": [
  "The week must start on Monday.",
  "Тиждень має починатися в понеділок."
 ],
 "Неделя — с понедельника по воскресенье. Прошлые отчёты доступны здесь, пока сохранена история.": [
  "Weeks run Monday through Sunday. Past reports remain here while history is kept.",
  "Тиждень триває з понеділка до неділі. Минулі звіти доступні тут, доки збережено історію."
 ],
 "Неделя, которую стоит запомнить.": [
  "A week worth remembering.",
  "Тиждень, який варто запам’ятати."
 ],
 "Недопустимая дата сессии.": [
  "Invalid session date.",
  "Недопустима дата сеансу."
 ],
 "Недопустимая дата.": [
  "Invalid date.",
  "Недопустима дата."
 ],
 "Неизвестная категория.": [
  "Unknown category.",
  "Невідома категорія."
 ],
 "Неизвестный тип сессии.": [
  "Unknown session type.",
  "Невідомий тип сеансу."
 ],
 "Некорректная граница суток": [
  "Invalid day boundary",
  "Некоректна межа доби"
 ],
 "Некорректный API-ключ FACEIT": [
  "Invalid FACEIT API key",
  "Некоректний API-ключ FACEIT"
 ],
 "Некорректный SteamID64": [
  "Invalid SteamID64",
  "Некоректний SteamID64"
 ],
 "Некорректный период": [
  "Invalid date range",
  "Некоректний період"
 ],
 "Неподдерживаемая ссылка Steam-профиля": [
  "Unsupported Steam profile link",
  "Непідтримуване посилання профілю Steam"
 ],
 "Нет данных для сравнения": [
  "No comparison data",
  "Немає даних для порівняння"
 ],
 "Нет данных о ранге": [
  "No rank data",
  "Немає даних про ранг"
 ],
 "Нет данных по категориям": [
  "No category data",
  "Немає даних за категоріями"
 ],
 "Нет данных предыдущей недели": [
  "No data for the previous week",
  "Немає даних попереднього тижня"
 ],
 "Нет ответа дополнения": [
  "No response from companion",
  "Немає відповіді доповнення"
 ],
 "Нет подключения к приложению Windows": [
  "Not connected to the Windows app",
  "Немає підключення до застосунку Windows"
 ],
 "Нет подключения — откройте TimeWrapped и проверьте код": [
  "Not connected — open TimeWrapped and check the code",
  "Немає підключення — відкрийте TimeWrapped і перевірте код"
 ],
 "Нет результата": [
  "Unknown result",
  "Немає результату"
 ],
 "Ниже сохранён последний успешный снимок.": [
  "The last successful snapshot is shown below.",
  "Нижче збережено останній успішний знімок."
 ],
 "Ночной исследователь": [
  "Night explorer",
  "Нічний дослідник"
 ],
 "Нужен SteamID64 или ссылка steamcommunity.com": [
  "Enter a SteamID64 or steamcommunity.com link",
  "Потрібен SteamID64 або посилання steamcommunity.com"
 ],
 "Нужен запуск Windows-приложения": [
  "Start the Windows app",
  "Потрібно запустити застосунок Windows"
 ],
 "ОБЗОР": [
  "OVERVIEW",
  "ОГЛЯД"
 ],
 "Оба режима используют Steam-профиль выше и не требуют входа в Steam. Публичный режим получает доступные FACEIT данные; при ограничении сервиса сохранится последний снимок.": [
  "Both modes use the Steam profile above and do not require Steam sign-in. Public mode retrieves available FACEIT data; the last snapshot is kept if the service limits access.",
  "Обидва режими використовують профіль Steam вище й не потребують входу в Steam. Публічний режим отримує доступні дані FACEIT; за обмеження сервісу зберігається останній знімок."
 ],
 "Обзор": [
  "Overview",
  "Огляд"
 ],
 "Обновить расширения": [
  "Refresh extensions",
  "Оновити розширення"
 ],
 "Обновить статистику": [
  "Refresh statistics",
  "Оновити статистику"
 ],
 "Обновление и приватность": [
  "Updates and privacy",
  "Оновлення та приватність"
 ],
 "Обновлено": [
  "Updated",
  "Оновлено"
 ],
 "Обновлено: {2}. Пока подключено, фоновое обновление — примерно раз в 15 минут. Ручное — не чаще раза в минуту.": [
  "Updated: {2}. While connected, background refresh runs about every 15 minutes. Manual refresh is limited to once a minute.",
  "Оновлено: {2}. Поки підключено, фонове оновлення виконується приблизно раз на 15 хвилин. Ручне — не частіше ніж раз на хвилину."
 ],
 "Обновляем…": [
  "Refreshing…",
  "Оновлюємо…"
 ],
 "Общение": [
  "Social",
  "Спілкування"
 ],
 "Один Steam-профиль для Dota и CS2": [
  "One Steam profile for Dota and CS2",
  "Один профіль Steam для Dota та CS2"
 ],
 "Одно дополнение TimeWrapped": [
  "One TimeWrapped companion",
  "Одне доповнення TimeWrapped"
 ],
 "Одно дополнение для всех функций. Только ваш ПК, без аккаунта и облака. Chrome / Edge.": [
  "One companion for every feature. Only your PC, no account or cloud. Chrome / Edge.",
  "Одне доповнення для всіх функцій. Лише ваш ПК, без облікового запису й хмари. Chrome / Edge."
 ],
 "Одно ненавязчивое уведомление после завершения недели с активностью.": [
  "One quiet notification after a completed week with activity.",
  "Одне ненав’язливе сповіщення після завершення тижня з активністю."
 ],
 "Ожидание первых данных": [
  "Waiting for your first data",
  "Очікуємо перші дані"
 ],
 "Окончание сессии должно быть позже начала.": [
  "Session end must be after its start.",
  "Завершення сеансу має бути пізніше за початок."
 ],
 "Оперативная память": [
  "Memory",
  "Оперативна пам’ять"
 ],
 "Операции записи процесса": [
  "Process write operations",
  "Операції запису процесу"
 ],
 "Определено {0}% времени. Жанры по исполнителям, с учётом ручного выбора.": [
  "Genres identified for {0}% of listening time. Artist genres include your manual choices.",
  "Жанри визначено для {0}% часу. Жанри виконавців враховують ручний вибір."
 ],
 "Определены жанры: {0}": [
  "Genres identified: {0}",
  "Визначено жанри: {0}"
 ],
 "Определить жанры MusicBrainz": [
  "Identify genres with MusicBrainz",
  "Визначити жанри MusicBrainz"
 ],
 "Основная навигация": [
  "Main navigation",
  "Основна навігація"
 ],
 "Основная статистика доступна. Не удалось обновить дополнительные данные:": [
  "Core statistics are available. Could not refresh additional data:",
  "Основна статистика доступна. Не вдалося оновити додаткові дані:"
 ],
 "От 5 матчей, по доле побед в доступной истории.": [
  "At least 5 matches, ranked by win rate in available history.",
  "Від 5 матчів, за часткою перемог у доступній історії."
 ],
 "Отдельная статистика 18+": [
  "Separate adult-site statistics",
  "Окрема статистика 18+"
 ],
 "Отключить игровые расширения": [
  "Disconnect gaming extensions",
  "Вимкнути ігрові розширення"
 ],
 "Откройте TimeWrapped и проверьте подключение": [
  "Open TimeWrapped and check the connection",
  "Відкрийте TimeWrapped і перевірте підключення"
 ],
 "Откройте подробности на выбранном сайте. Источник цифр внутри TimeWrapped — OpenDota.": [
  "Open details on the selected site. TimeWrapped’s numbers come from OpenDota.",
  "Відкрийте подробиці на вибраному сайті. Джерело чисел у TimeWrapped — OpenDota."
 ],
 "Откройте привычные программы — TimeWrapped начнёт складывать вашу историю.": [
  "Open your usual apps — TimeWrapped will start building your story.",
  "Відкрийте звичні програми — TimeWrapped почне складати вашу історію."
 ],
 "Открыть FACEIT": [
  "Open FACEIT",
  "Відкрити FACEIT"
 ],
 "Открыть TimeWrapped": [
  "Open TimeWrapped",
  "Відкрити TimeWrapped"
 ],
 "Открыть Wrapped{0}": [
  "Open Wrapped{0}",
  "Відкрити Wrapped{0}"
 ],
 "Открыть в отдельной вкладке": [
  "Open in a separate tab",
  "Відкрити в окремій вкладці"
 ],
 "Открыть настройки": [
  "Open settings",
  "Відкрити налаштування"
 ],
 "Отмена": [
  "Cancel",
  "Скасувати"
 ],
 "Отметьте FACEIT CS2 при подключении Steam-профиля": [
  "Select FACEIT CS2 when connecting your Steam profile",
  "Позначте FACEIT CS2 під час підключення профілю Steam"
 ],
 "Отслеживание активно": [
  "Tracking active",
  "Відстеження активне"
 ],
 "Отслеживание на паузе": [
  "Tracking paused",
  "Відстеження на паузі"
 ],
 "Отслеживание приостановлено": [
  "Tracking paused",
  "Відстеження призупинено"
 ],
 "Отслеживание продолжено": [
  "Tracking resumed",
  "Відстеження відновлено"
 ],
 "Отслеживать экранное время": [
  "Track screen time",
  "Відстежувати екранний час"
 ],
 "Официальный Data API · свой ключ": [
  "Official Data API · your own key",
  "Офіційний Data API · власний ключ"
 ],
 "ПЕРВАЯ ГЛАВА УЖЕ ПИШЕТСЯ": [
  "YOUR FIRST CHAPTER IS TAKING SHAPE",
  "ПЕРШИЙ РОЗДІЛ УЖЕ ПИШЕТЬСЯ"
 ],
 "ПК ВКЛЮЧЁН": [
  "PC POWERED ON",
  "ПК УВІМКНЕНО"
 ],
 "ПК без сна": [
  "PC awake time",
  "ПК без сну"
 ],
 "ПК включён (учтено)": [
  "PC uptime (recorded)",
  "ПК увімкнено (обліковано)"
 ],
 "ПРИ ВХОДЕ В ПРОФИЛЬ": [
  "WHEN YOU SIGN IN",
  "ПІД ЧАС ВХОДУ В ПРОФІЛЬ"
 ],
 "Пароль и Steam Guard не нужны. Указанный идентификатор передаётся выбранным сервисам. Dota использует публичные данные OpenDota; FACEIT доступен без ключа или через API по вашему выбору.": [
  "No password or Steam Guard needed. Your identifier is sent to the selected services. Dota uses public OpenDota data; choose public FACEIT or your own API key.",
  "Пароль і Steam Guard не потрібні. Ваш ідентифікатор передається вибраним сервісам. Dota використовує публічні дані OpenDota; FACEIT доступний без ключа або через API на ваш вибір."
 ],
 "Пауза и запуск без музыки не считаются. В свёрнутом окне музыка учитывается. Проверяем Windows Playing и активный локальный аудиовыход без mute; история названий треков включается отдельно в «Расширениях».": [
  "Pauses and launch without playback do not count. Music counts with Spotify minimized. We check Windows Playing and active unmuted local audio. Track-title history is enabled separately in Extensions.",
  "Пауза та запуск без музики не враховуються. У згорнутому вікні музика враховується. Перевіряємо Windows Playing та активний локальний звук без вимкнення гучності. Історія назв треків вмикається окремо в «Розширеннях»."
 ],
 "Первые данные появятся во время использования компьютера": [
  "Your first data will appear as you use the computer",
  "Перші дані з’являться під час використання комп’ютера"
 ],
 "Первые интервалы появятся после запуска новой версии.": [
  "The first intervals will appear after you launch the new version.",
  "Перші інтервали з’являться після запуску нової версії."
 ],
 "Первые привычки скоро проявятся": [
  "Your first habits will emerge soon",
  "Перші звички скоро проявляться"
 ],
 "Переключения": [
  "Switches",
  "Перемикання"
 ],
 "Период статистики": [
  "Statistics period",
  "Період статистики"
 ],
 "По дату": [
  "End date",
  "До дати"
 ],
 "По категориям": [
  "By category",
  "За категоріями"
 ],
 "По одному домену в строке": [
  "One domain per line",
  "По одному домену в рядку"
 ],
 "По умолчанию записываются только домены": [
  "Only domains are recorded by default",
  "Типово записуються лише домени"
 ],
 "Победа": [
  "Win",
  "Перемога"
 ],
 "Победы": [
  "Wins",
  "Перемоги"
 ],
 "Победы · всего": [
  "Wins · all time",
  "Перемоги · загалом"
 ],
 "Подготовка вкладок превысила время ожидания": [
  "Preparing tabs exceeded the time limit",
  "Підготовка вкладок перевищила час очікування"
 ],
 "Поддерживается только https://steamcommunity.com/profiles/… или /id/…": [
  "Only https://steamcommunity.com/profiles/… or /id/… is supported",
  "Підтримується лише https://steamcommunity.com/profiles/… або /id/…"
 ],
 "Подключаем…": [
  "Connecting…",
  "Підключаємо…"
 ],
 "Подключение…": [
  "Connecting…",
  "Підключення…"
 ],
 "Подключения включаются отдельно. Учёт времени ПК работает независимо от игровых сервисов.": [
  "Connections are optional. PC time tracking works independently of gaming services.",
  "Підключення вмикаються окремо. Облік часу ПК працює незалежно від ігрових сервісів."
 ],
 "Подключено · TimeWrapped": [
  "Connected · TimeWrapped",
  "Підключено · TimeWrapped"
 ],
 "Подключено · сбор приостановлен в приложении": [
  "Connected · tracking paused in the app",
  "Підключено · збір призупинено в застосунку"
 ],
 "Подключено: история активных сайтов": [
  "Connected: active website history",
  "Підключено: історія активних сайтів"
 ],
 "Подключите Steam-профиль и отметьте Dota 2": [
  "Connect your Steam profile and select Dota 2",
  "Підключіть профіль Steam і позначте Dota 2"
 ],
 "Подключите профиль и нажмите обновление расширений.": [
  "Connect a profile and refresh extensions.",
  "Підключіть профіль і натисніть оновлення розширень."
 ],
 "Подключить": [
  "Connect",
  "Підключити"
 ],
 "Подключить / обновить": [
  "Connect / refresh",
  "Підключити / оновити"
 ],
 "Подключить браузер": [
  "Connect browser",
  "Підключити браузер"
 ],
 "Подробности истории": [
  "History details",
  "Подробиці історії"
 ],
 "Подтверждённое воспроизведение за выбранный период": [
  "Confirmed playback in the selected period",
  "Підтверджене відтворення за вибраний період"
 ],
 "Поиск жанров MusicBrainz": [
  "MusicBrainz genre lookup",
  "Пошук жанрів MusicBrainz"
 ],
 "Пока мало данных": [
  "Not much data yet",
  "Поки мало даних"
 ],
 "Пока не хватает данных для определения самого активного дня.": [
  "Not enough data to find your busiest day yet.",
  "Поки недостатньо даних, щоб визначити найактивніший день."
 ],
 "Пока недостаточно данных.": [
  "Not enough data yet.",
  "Поки недостатньо даних."
 ],
 "Пока нет данных за выбранный период.": [
  "No data for the selected period yet.",
  "Поки немає даних за вибраний період."
 ],
 "Пока нет данных.": [
  "No data yet.",
  "Поки немає даних."
 ],
 "Пока нет загруженных матчей": [
  "No matches loaded yet",
  "Поки немає завантажених матчів"
 ],
 "Пока нет прослушиваний за период.": [
  "No listening data in this period yet.",
  "Поки немає прослуховувань за період."
 ],
 "Показатели относятся к сборщику. CPU усреднён с запуска и нормирован на число логических процессоров; загрузка одного ядра также доступна ниже. Число операций ОС и число транзакций SQLite — разные метрики.": [
  "Metrics refer to the collector. CPU is averaged since launch and normalized by logical processor count; single-core usage is shown below. OS write operations and SQLite transactions are different metrics.",
  "Показники стосуються збирача. CPU усереднено від запуску та нормовано на кількість логічних процесорів; навантаження одного ядра показано нижче. Операції ОС і транзакції SQLite — різні метрики."
 ],
 "Показать": [
  "Show",
  "Показати"
 ],
 "Показать приложения": [
  "Filter apps",
  "Показати застосунки"
 ],
 "Показывать жанры в итогах": [
  "Show genres in highlights",
  "Показувати жанри в підсумках"
 ],
 "Полностью выйти": [
  "Quit completely",
  "Повністю вийти"
 ],
 "Популярные сайты и отдельные истории": [
  "Popular sites and their history",
  "Популярні сайти та їхні історії"
 ],
 "Поражение": [
  "Loss",
  "Поразка"
 ],
 "Порог простоя в секундах": [
  "Idle threshold in seconds",
  "Поріг простою в секундах"
 ],
 "Порог простоя должен быть от 15 до 3600 секунд.": [
  "Idle threshold must be between 15 and 3600 seconds.",
  "Поріг простою має бути від 15 до 3600 секунд."
 ],
 "Порт 38671 занят. Закройте другой экземпляр TimeWrapped и перезапустите приложение": [
  "Port 38671 is busy. Close the other TimeWrapped instance and restart the app.",
  "Порт 38671 зайнятий. Закрийте інший екземпляр TimeWrapped і перезапустіть застосунок."
 ],
 "Посещение не найдено": [
  "Visit not found",
  "Відвідування не знайдено"
 ],
 "После подключения дополнения откройте сайт. Первые интервалы появятся через несколько секунд.": [
  "Open a website after connecting the companion. The first intervals appear in a few seconds.",
  "Після підключення доповнення відкрийте сайт. Перші інтервали з’являться за кілька секунд."
 ],
 "После порога перестаёт расти активный фокус. Время ПК и видимых окон продолжается.": [
  "Active focus stops growing after the threshold. PC time and visible-window time continue.",
  "Після порога активний фокус перестає зростати. Час ПК та видимих вікон продовжується."
 ],
 "Последние 20 · победы": [
  "Last 20 · wins",
  "Останні 20 · перемоги"
 ],
 "Последние 30 дней": [
  "Last 30 days",
  "Останні 30 днів"
 ],
 "Последние 7 дней": [
  "Last 7 days",
  "Останні 7 днів"
 ],
 "Посмотреть итоги": [
  "View highlights",
  "Переглянути підсумки"
 ],
 "Постоянные напарники": [
  "Regular teammates",
  "Постійні напарники"
 ],
 "Правило приложения сохранено": [
  "App rule saved",
  "Правило застосунку збережено"
 ],
 "Приложение": [
  "App",
  "Застосунок"
 ],
 "Приложение не найдено.": [
  "App not found.",
  "Застосунок не знайдено."
 ],
 "Приложение не подключено": [
  "App not connected",
  "Застосунок не підключено"
 ],
 "Приложения и категории": [
  "Apps and categories",
  "Застосунки та категорії"
 ],
 "Приложения на экране за период": [
  "Apps on screen in this period",
  "Застосунки на екрані за період"
 ],
 "Приложения появятся здесь после первой активности.": [
  "Apps appear here after their first activity.",
  "Застосунки з’являться тут після першої активності."
 ],
 "Применить заново": [
  "Apply again",
  "Застосувати знову"
 ],
 "Приостановить": [
  "Pause",
  "Призупинити"
 ],
 "Приостановить отслеживание": [
  "Pause tracking",
  "Призупинити відстеження"
 ],
 "Приостановить сбор в браузере": [
  "Pause browser tracking",
  "Призупинити збір у браузері"
 ],
 "Проверьте домены в списке": [
  "Check the domain list",
  "Перевірте домени у списку"
 ],
 "Проверьте исполнителя и жанр": [
  "Check the artist and genre",
  "Перевірте виконавця та жанр"
 ],
 "Проверяем запись автозапуска…": [
  "Checking startup registration…",
  "Перевіряємо запис автозапуску…"
 ],
 "Проверяем подключение…": [
  "Checking connection…",
  "Перевіряємо підключення…"
 ],
 "Продолжить": [
  "Resume",
  "Продовжити"
 ],
 "Продолжить отслеживание": [
  "Resume tracking",
  "Продовжити відстеження"
 ],
 "Продолжить разбор": [
  "Continue exploring",
  "Продовжити перегляд"
 ],
 "Профиль Dota 2": [
  "Dota 2 profile",
  "Профіль Dota 2"
 ],
 "РАСШИРЕНИЯ": [
  "EXTENSIONS",
  "РОЗШИРЕННЯ"
 ],
 "Работа": [
  "Work",
  "Робота"
 ],
 "Работали в фоне": [
  "Ran in the background",
  "Працювали у фоні"
 ],
 "Развлечения": [
  "Entertainment",
  "Розваги"
 ],
 "Ранее: {3}": [
  "Previously: {3}",
  "Раніше: {3}"
 ],
 "Расширения": [
  "Extensions",
  "Розширення"
 ],
 "Реальные измерения процесса, без WebView. Обновляются по запросу.": [
  "Actual process measurements, without WebView. Updated on request.",
  "Справжні вимірювання процесу, без WebView. Оновлюються за запитом."
 ],
 "Режим автозапуска": [
  "Startup mode",
  "Режим автозапуску"
 ],
 "Режим появится после первых активных сессий.": [
  "Your pattern will appear after the first active sessions.",
  "Режим з’явиться після перших активних сеансів."
 ],
 "Результат": [
  "Result",
  "Результат"
 ],
 "Ресурсы сборщика": [
  "Collector resources",
  "Ресурси збирача"
 ],
 "Ритм определяется по распределению реального активного времени по локальным часам. Ритм строится по активному фокусу; сон и простой не влияют на характер.": [
  "Your rhythm is based on actual active time by local hour. It uses active focus; sleep and idle time do not affect your type.",
  "Ритм визначається за розподілом справжнього активного часу за місцевими годинами. Він ґрунтується на активному фокусі; сон і простій не впливають на тип."
 ],
 "С даты": [
  "Start date",
  "З дати"
 ],
 "С запуска Windows сейчас:": [
  "Since Windows started:",
  "Від запуску Windows зараз:"
 ],
 "С открытым окном": [
  "With the window open",
  "З відкритим вікном"
 ],
 "Сайт / страница": [
  "Website / page",
  "Сайт / сторінка"
 ],
 "Сайтов": [
  "Websites",
  "Сайтів"
 ],
 "Сайты": [
  "Websites",
  "Сайти"
 ],
 "Сайты и SoundCloud приостановлены. Spotify управляется приложением.": [
  "Websites and SoundCloud are paused. Spotify is controlled by the app.",
  "Сайти та SoundCloud призупинено. Spotify керується застосунком."
 ],
 "Сайты и музыка · 1.0.2": [
  "Websites and music · 1.0.2",
  "Сайти та музика · 1.0.2"
 ],
 "Сайты, SoundCloud и управление историей Spotify — в одной панели браузера. Один код подключения для всех функций.": [
  "Websites, SoundCloud and Spotify history settings in one browser panel. One pairing code for every feature.",
  "Сайти, SoundCloud і налаштування історії Spotify — в одній панелі браузера. Один код підключення для всіх функцій."
 ],
 "Сбор активности": [
  "Activity tracking",
  "Збір активності"
 ],
 "Сбор в браузере возобновлён.": [
  "Browser tracking resumed.",
  "Збір у браузері відновлено."
 ],
 "Сборщик не завершился: статистика не сохранена": [
  "The collector did not exit: statistics were not saved",
  "Збирач не завершився: статистику не збережено"
 ],
 "Сборщик не ответил на запрос сохранения": [
  "The collector did not respond to the save request",
  "Збирач не відповів на запит збереження"
 ],
 "Сборщик не подтвердил выход": [
  "The collector did not confirm exit",
  "Збирач не підтвердив вихід"
 ],
 "Сборщик недоступен": [
  "Collector unavailable",
  "Збирач недоступний"
 ],
 "Свой ритм": [
  "Your own rhythm",
  "Власний ритм"
 ],
 "Сеансы": [
  "Visits",
  "Відвідування"
 ],
 "Сегодня": [
  "Today",
  "Сьогодні"
 ],
 "Сейчас с запуска Windows:": [
  "Since Windows started:",
  "Зараз від запуску Windows:"
 ],
 "Сейчас складываются первые моменты. После завершения недели — ваша личная история.": [
  "Your first moments are coming together. Your personal story appears once the week is complete.",
  "Зараз складаються перші моменти. Після завершення тижня — ваша особиста історія."
 ],
 "Семь дней.": [
  "Seven days.",
  "Сім днів."
 ],
 "Сервис": [
  "Service",
  "Сервіс"
 ],
 "Сервис не вернул завершённые матчи CS2.": [
  "The service returned no completed CS2 matches.",
  "Сервіс не повернув завершені матчі CS2."
 ],
 "Скопируйте выделенный код: Ctrl+C": [
  "Copy the selected code: Ctrl+C",
  "Скопіюйте виділений код: Ctrl+C"
 ],
 "Скопируйте код: Ctrl+C": [
  "Copy the code: Ctrl+C",
  "Скопіюйте код: Ctrl+C"
 ],
 "См. ниже": [
  "See below",
  "Див. нижче"
 ],
 "Сначала укажите Steam-профиль": [
  "Enter a Steam profile first",
  "Спочатку вкажіть профіль Steam"
 ],
 "Собираем вашу историю…": [
  "Building your story…",
  "Збираємо вашу історію…"
 ],
 "Сова": [
  "Night owl",
  "Сова"
 ],
 "Совсем другая история.": [
  "A whole new story.",
  "Зовсім інша історія."
 ],
 "Сон": [
  "Sleep",
  "Сон"
 ],
 "Сохраните ZIP и распакуйте в постоянную папку.": [
  "Save the ZIP and extract it to a permanent folder.",
  "Збережіть ZIP і розпакуйте в постійну папку."
 ],
 "Сохранить единое дополнение ZIP": [
  "Save the single companion ZIP",
  "Зберегти єдине доповнення ZIP"
 ],
 "Сохранить ключ": [
  "Save key",
  "Зберегти ключ"
 ],
 "Сохранить списки": [
  "Save lists",
  "Зберегти списки"
 ],
 "Сохраняется только эта карточка с итогами выбранной недели.": [
  "Only this highlights card for the selected week will be saved.",
  "Зберігається лише ця картка з підсумками вибраного тижня."
 ],
 "Сохранять названия и пути страниц": [
  "Save page titles and paths",
  "Зберігати назви та шляхи сторінок"
 ],
 "Сохранять посещения известных и добавленных вами 18+ доменов. Они появятся в разделе «Дрочун» и личной части итогов.": [
  "Record visits to known adult domains and ones you add. They appear in Adult sites and private highlights.",
  "Зберігати відвідування відомих і доданих вами доменів 18+. Вони з’являться в розділі «Сайти 18+» та особистих підсумках."
 ],
 "Сохраняются названия и исполнители только после включения. Старую историю сервисов не загружаем. Ниже последние 100 сеансов; общие итоги — за всё время.": [
  "Titles and artists are saved only after you enable history. Past service history is not imported. The latest 100 sessions are below; totals cover all time.",
  "Назви та виконавці зберігаються лише після ввімкнення. Стара історія сервісів не імпортується. Нижче останні 100 сеансів; загальні підсумки — за весь час."
 ],
 "Списки сохранены": [
  "Lists saved",
  "Списки збережено"
 ],
 "Способ подключения": [
  "Connection method",
  "Спосіб підключення"
 ],
 "Средние K / D / A": [
  "Average K / D / A",
  "Середні K / D / A"
 ],
 "Средний K/D": [
  "Average K/D",
  "Середній K/D"
 ],
 "Статистика остаётся в памяти. Проверьте доступ к папке данных.": [
  "Statistics remain in memory. Check access to the data folder.",
  "Статистика залишається в пам’яті. Перевірте доступ до папки даних."
 ],
 "Столько времени сложилось из больших идей, маленьких пауз и любимых приложений.": [
  "That much time was made of big ideas, little breaks and favourite apps.",
  "Стільки часу склалося з великих ідей, маленьких пауз та улюблених застосунків."
 ],
 "Считать простоем через": [
  "Mark as idle after",
  "Вважати простоєм через"
 ],
 "Счёт": [
  "Score",
  "Рахунок"
 ],
 "ТВОЙ ТОП-3": [
  "YOUR TOP 3",
  "ТВІЙ ТОП-3"
 ],
 "ТВОЯ ЦИФРОВАЯ НЕДЕЛЯ": [
  "YOUR DIGITAL WEEK",
  "ТВІЙ ЦИФРОВИЙ ТИЖДЕНЬ"
 ],
 "ТОП 5": [
  "TOP 5",
  "ТОП 5"
 ],
 "Твои итоги недели готовы! Открой TimeWrapped из трея.": [
  "Your weekly highlights are ready! Open TimeWrapped from the tray.",
  "Твої підсумки тижня готові! Відкрий TimeWrapped із трея."
 ],
 "Твой ритм меняется.": [
  "Your rhythm is changing.",
  "Твій ритм змінюється."
 ],
 "Творческий экспериментатор": [
  "Creative experimenter",
  "Творчий експериментатор"
 ],
 "Творчество": [
  "Creativity",
  "Творчість"
 ],
 "Твоя история начинается": [
  "Your story begins",
  "Твоя історія починається"
 ],
 "Твоё время. Твоя история.": [
  "Your time. Your story.",
  "Твій час. Твоя історія."
 ],
 "Текущая завершённая неделя в сравнении с предыдущей.": [
  "The latest completed week compared with the previous one.",
  "Останній завершений тиждень порівняно з попереднім."
 ],
 "Текущая серия": [
  "Current streak",
  "Поточна серія"
 ],
 "Тихо работает в фоне": [
  "Quietly running in the background",
  "Тихо працює у фоні"
 ],
 "Только в трее": [
  "Tray only",
  "Лише в треї"
 ],
 "Только в фоне": [
  "Background only",
  "Лише у фоні"
 ],
 "Только вкладка на экране с фокусом": [
  "Only the active tab in a focused window",
  "Лише активна вкладка вікна з фокусом"
 ],
 "Только на вашем ПК.": [
  "Only on your PC.",
  "Лише на вашому ПК."
 ],
 "Только приложения с пользовательскими окнами. Служебные процессы скрыты, в том числе из старой статистики. Категории и исключения применяются к накопленной истории.": [
  "Only apps with user-facing windows. Supporting processes are hidden, including from old statistics. Categories and exclusions apply to past history.",
  "Лише застосунки з користувацькими вікнами. Службові процеси приховані, зокрема зі старої статистики. Категорії та винятки застосовуються до накопиченої історії."
 ],
 "Топ приложений на экране": [
  "Top apps on screen",
  "Топ застосунків на екрані"
 ],
 "Трек": [
  "Track",
  "Трек"
 ],
 "Треки и время воспроизведения": [
  "Tracks and playback time",
  "Треки та час відтворення"
 ],
 "Тысячи маленьких": [
  "Thousands of little",
  "Тисячі маленьких"
 ],
 "У каждого дня есть история.": [
  "Every day has a story.",
  "У кожного дня є історія."
 ],
 "У каждого дня свой ритм": [
  "Every day has its rhythm",
  "У кожного дня свій ритм"
 ],
 "УДАЛИТЬ": [
  "DELETE",
  "ВИДАЛИТИ"
 ],
 "Уведомления о Weekly Wrapped": [
  "Weekly Wrapped notifications",
  "Сповіщення про Weekly Wrapped"
 ],
 "Уведомлять о Weekly Wrapped": [
  "Notify me about Weekly Wrapped",
  "Сповіщати про Weekly Wrapped"
 ],
 "Удалить": [
  "Delete",
  "Видалити"
 ],
 "Удалить всю историю?": [
  "Delete all history?",
  "Видалити всю історію?"
 ],
 "Удалить всю собранную историю": [
  "Delete all recorded history",
  "Видалити всю зібрану історію"
 ],
 "Удалить данные": [
  "Delete data",
  "Видалити дані"
 ],
 "Удалить историю 18+?": [
  "Delete adult-site history?",
  "Видалити історію 18+?"
 ],
 "Удалить историю 18+…": [
  "Delete adult-site history…",
  "Видалити історію 18+…"
 ],
 "Удалить ключ": [
  "Remove key",
  "Видалити ключ"
 ],
 "Удаляет сессии, статистику приложений и прошлые отчёты. Настройки сохранятся.": [
  "Deletes sessions, app statistics and past reports. Settings are kept.",
  "Видаляє сеанси, статистику застосунків і минулі звіти. Налаштування зберігаються."
 ],
 "Узнайте, кто стал вашим фаворитом, когда вы были особенно активны и какой цифровой характер скрывается за привычками.": [
  "Discover your favourite app, your most active hours and the digital personality behind your habits.",
  "Дізнайтеся, хто став вашим фаворитом, коли ви були найактивніші та який цифровий характер стоїть за звичками."
 ],
 "Укажите жанр": [
  "Enter a genre",
  "Укажіть жанр"
 ],
 "Укажите от 15 до 3600 секунд": [
  "Enter a value between 15 and 3600 seconds",
  "Укажіть від 15 до 3600 секунд"
 ],
 "Уровень CS2": [
  "CS2 level",
  "Рівень CS2"
 ],
 "Учитывать активные сайты": [
  "Track active websites",
  "Враховувати активні сайти"
 ],
 "Учитываются время ПК, активный фокус и видимые приложения на всех мониторах.": [
  "Tracks PC time, active focus and visible apps across all monitors.",
  "Враховує час ПК, активний фокус і видимі застосунки на всіх моніторах."
 ],
 "Учтённое время, включая простой, блокировку и сон.": [
  "Recorded time, including idle, lock and sleep.",
  "Облікований час, зокрема простій, блокування та сон."
 ],
 "Учёба": [
  "Study",
  "Навчання"
 ],
 "Учёт 18+ выключен.": [
  "Adult-site tracking is off.",
  "Облік 18+ вимкнено."
 ],
 "Учёт сайтов 18+": [
  "Track adult sites",
  "Облік сайтів 18+"
 ],
 "Фоновый сборщик Windows": [
  "Windows background collector",
  "Фоновий збирач Windows"
 ],
 "Фоновый сборщик не запустился. Проверьте agent-error.log в папке данных.": [
  "The background collector did not start. Check agent-error.log in the data folder.",
  "Фоновий збирач не запустився. Перевірте agent-error.log у папці даних."
 ],
 "Фоновый сборщик не запущен": [
  "The background collector is not running",
  "Фоновий збирач не запущено"
 ],
 "Фоновый сборщик продолжает работу после закрытия окна.": [
  "The background collector keeps running when you close the window.",
  "Фоновий збирач продовжує працювати після закриття вікна."
 ],
 "Фоновый учёт добавлен в 0.3: прежнюю работу скрытых программ восстановить нельзя. Старое время видимых окон сохранено как известный минимум запущенного времени. Обнаружение процессов — до 15 секунд, закрытия — до 5 секунд; видимость — по событиям окна.": [
  "Background tracking was added in 0.3: past hidden-app activity cannot be reconstructed. Old visible time is kept as the known minimum running time. Process discovery takes up to 15 seconds, exits up to 5 seconds; visibility follows window events.",
  "Фоновий облік додано у 0.3: минулу роботу прихованих програм відновити неможливо. Старий час видимості збережено як відомий мінімум запущеного часу. Виявлення процесів — до 15 секунд, закриття — до 5 секунд; видимість — за подіями вікна."
 ],
 "Цифровой минималист": [
  "Digital minimalist",
  "Цифровий мінімаліст"
 ],
 "Что входит во время": [
  "What time includes",
  "Що входить у час"
 ],
 "Чтобы собирать эту статистику, включите историю сайтов и учёт 18+ во вкладке «Расширения → Сайты». Сначала настройте браузерное дополнение.": [
  "To collect these statistics, enable website history and adult-site tracking in Extensions → Websites. Set up the browser companion first.",
  "Щоб збирати цю статистику, увімкніть історію сайтів та облік 18+ у «Розширення → Сайти». Спочатку налаштуйте браузерне доповнення."
 ],
 "Экран {2} из {3}": [
  "Slide {2} of {3}",
  "Екран {2} із {3}"
 ],
 "Экраны истории": [
  "Story slides",
  "Екрани історії"
 ],
 "Экспорт сохранён:": [
  "Export saved:",
  "Експорт збережено:"
 ],
 "Экспортируйте локальную историю в удобном формате.": [
  "Export your local history in a convenient format.",
  "Експортуйте локальну історію в зручному форматі."
 ],
 "Эта неделя": [
  "This week",
  "Цей тиждень"
 ],
 "Это описание привычек за выбранную неделю. Правило выбора основано на длительности, категориях, часах активности и переключениях.": [
  "This describes habits for the selected week. The selection rule uses duration, categories, active hours and switches.",
  "Це опис звичок за вибраний тиждень. Правило вибору ґрунтується на тривалості, категоріях, годинах активності та перемиканнях."
 ],
 "Это предпросмотр интерфейса. Откройте TimeWrapped.exe в Windows, чтобы включить сборщик и увидеть настоящую статистику.": [
  "This is a UI preview. Open TimeWrapped.exe on Windows to start the collector and view real statistics.",
  "Це попередній перегляд інтерфейсу. Відкрийте TimeWrapped.exe у Windows, щоб запустити збирач і побачити справжню статистику."
 ],
 "Этот месяц": [
  "This month",
  "Цей місяць"
 ],
 "Этот раздел доступен внутри приложения. Обычная PNG-карточка содержит общие итоги приложений.": [
  "This section is available inside the app. The standard PNG card contains general app highlights.",
  "Цей розділ доступний усередині застосунку. Звичайна PNG-картка містить загальні підсумки застосунків."
 ],
 "Я": [
  "Me",
  "Я"
 ],
 "ваша неделя.": [
  "your week.",
  "ваш тиждень."
 ],
 "включите режим разработчика → «Загрузить распакованное расширение».": [
  "enable developer mode → “Load unpacked”.",
  "увімкніть режим розробника → «Завантажити розпаковане розширення»."
 ],
 "для подтверждения": [
  "to confirm",
  "для підтвердження"
 ],
 "или": [
  "or",
  "або"
 ],
 "категорий": [
  "categories",
  "категорій"
 ],
 "мин": [
  "min",
  "хв"
 ],
 "моментов.": [
  "moments.",
  "моментів."
 ],
 "нашлось время.": [
  "there was time.",
  "знайшовся час."
 ],
 "побед": [
  "wins",
  "перемог"
 ],
 "пока нет": [
  "not yet",
  "поки немає"
 ],
 "пока нет данных": [
  "no data yet",
  "поки немає даних"
 ],
 "поражений": [
  "losses",
  "поразок"
 ],
 "с одного дня.": [
  "with one day.",
  "з одного дня."
 ],
 "сек": [
  "sec",
  "с"
 ],
 "сек.": [
  "sec.",
  "с."
 ],
 "твоя цифровая неделя.": [
  "your digital week.",
  "твій цифровий тиждень."
 ],
 "ч": [
  "h",
  "год"
 ],
 "{11}Экспорт JSON": [
  "{11}Export JSON",
  "{11}Експорт JSON"
 ],
 "{13}Экспорт CSV": [
  "{13}Export CSV",
  "{13}Експорт CSV"
 ],
 "{16}Измерить": [
  "{16}Measure",
  "{16}Виміряти"
 ],
 "{19}Удалить данные": [
  "{19}Delete data",
  "{19}Видалити дані"
 ],
 "{4} посещений": [
  "{4} visits",
  "{4} відвідувань"
 ],
 "Время показано суммарно по сайтам. В списке — переходы по страницам, без длительности отдельных окон.": [
  "Time is shown by website. The list shows page visits without durations for individual windows.",
  "Час показано сумарно за сайтами. У списку — переходи сторінками без тривалості окремих вікон."
 ],
 "Выбор сохраняется на этом компьютере.": [
  "Your choice is saved on this computer.",
  "Вибір зберігається на цьому комп’ютері."
 ],
 "Измените поиск, сайт или выбранный период.": [
  "Change your search, website or date range.",
  "Змініть пошук, сайт або вибраний період."
 ],
 "История посещений": [
  "Browsing history",
  "Історія відвідувань"
 ],
 "Название страницы или сайт": [
  "Page title or website",
  "Назва сторінки або сайт"
 ],
 "Поиск в истории": [
  "Search history",
  "Пошук в історії"
 ],
 "Показано {4} из {5} посещений за период. Возврат к открытой вкладке не создаёт новое посещение.": [
  "Showing {4} of {5} visits in this period. Returning to an open tab does not create a new visit.",
  "Показано {4} із {5} відвідувань за період. Повернення до відкритої вкладки не створює нове відвідування."
 ],
 "Посещений не найдено": [
  "No visits found",
  "Відвідувань не знайдено"
 ],
 "Язык интерфейса": [
  "Interface language",
  "Мова інтерфейсу"
 ],
 "Язык приложения": [
  "App language",
  "Мова застосунку"
 ],
 "Weekly Wrapped": [
  "Weekly Wrapped",
  "Тижневі підсумки"
 ],
 "WEEKLY WRAPPED": [
  "WEEKLY WRAPPED",
  "ТИЖНЕВІ ПІДСУМКИ"
 ],
 "Язык": [
  "Language",
  "Мова"
 ],
 "Неподдерживаемый язык": [
  "Unsupported language",
  "Непідтримувана мова"
 ],
 "Проверяем состояние Spotify…": [
  "Checking Spotify…",
  "Перевіряємо стан Spotify…"
 ],
 "Медиастатус Windows временно недоступен": [
  "Windows media status is temporarily unavailable",
  "Медіастатус Windows тимчасово недоступний"
 ],
 "Spotify не воспроизводит через медиасессию Windows": [
  "Spotify is not playing through Windows media sessions",
  "Spotify не відтворює через медіасесію Windows"
 ],
 "Spotify: пауза": [
  "Spotify: paused",
  "Spotify: пауза"
 ],
 "Spotify играет на этом ПК": [
  "Spotify is playing on this PC",
  "Spotify відтворює на цьому ПК"
 ],
 "Нет локального звука Spotify: пауза, mute или другое устройство": [
  "No local Spotify audio: paused, muted or playing on another device",
  "Немає локального звуку Spotify: пауза, вимкнений звук або інший пристрій"
 ],
 "Не удалось подтвердить локальный звук Spotify": [
  "Could not confirm local Spotify audio",
  "Не вдалося підтвердити локальний звук Spotify"
 ],
 "Windows не предоставила медиастатус: {0}": [
  "Windows did not provide media status: {0}",
  "Windows не надала медіастатус: {0}"
 ],
 "manual": [
  "Manual",
  "Вручну"
 ],
 "MusicBrainz · исполнитель": [
  "MusicBrainz · artist",
  "MusicBrainz · виконавець"
 ],
 "Некорректный адрес страницы": [
  "Invalid page address",
  "Некоректна адреса сторінки"
 ],
 "Не удалось открыть страницу": [
  "Could not open the page",
  "Не вдалося відкрити сторінку"
 ],
 "Нажмите «Подключить», чтобы обновить состояние": [
  "Click “Connect” to refresh the status",
  "Натисніть «Підключити», щоб оновити стан"
 ],
 "Сайты и музыка · 1.1.0": [
  "Websites and music · 1.1.0",
  "Сайти та музика · 1.1.0"
 ],
 "Посещения": [
  "Visits",
  "Відвідування"
 ],
 "Время и посещения сайтов 18+.": [
  "Time and visits on adult sites.",
  "Час і відвідування сайтів 18+."
 ],
 "Истекло время ожидания": [
  "Operation timed out",
  "Час очікування минув"
 ],
 "Дополнительно к доменам. Служебные параметры и фрагменты URL отбрасываются; для YouTube сохраняется только ID видео.": [
  "In addition to domains. Tracking parameters and URL fragments are removed; YouTube keeps only the video ID.",
  "Додатково до доменів. Службові параметри та фрагменти URL відкидаються; для YouTube зберігається лише ID відео."
 ],
 "Инкогнито и старая история не собираются. Пароли, служебные параметры URL и содержимое страниц не передаются. Для YouTube сохраняется ID видео. Списки исключений находятся в приложении.": [
  "Incognito and past history are not collected. Passwords, tracking parameters and page contents are not sent. YouTube video IDs are kept. Exclusion lists are in the app.",
  "Інкогніто та стара історія не збираються. Паролі, службові параметри URL і вміст сторінок не передаються. Для YouTube зберігається ID відео. Списки винятків — у застосунку."
 ],
 "В старой истории не сохранён ID видео": [
  "The video ID was not saved in the old history",
  "У старій історії не збережено ID відео"
 ]
};
